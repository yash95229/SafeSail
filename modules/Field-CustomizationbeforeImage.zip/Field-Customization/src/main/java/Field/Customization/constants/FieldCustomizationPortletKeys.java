package Field.Customization.constants;

/**
 * @author Yash
 */
public class FieldCustomizationPortletKeys {

	public static final String FIELDCUSTOMIZATION =
		"Field_Customization_FieldCustomizationPortlet";

}